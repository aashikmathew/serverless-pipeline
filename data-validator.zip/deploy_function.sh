#!/bin/bash
cd src/functions/data_validator
pip install -r requirements.txt -t .
zip -r ../data-validator.zip .
gsutil cp ../data-validator.zip gs://$(terraform output -raw static_assets_bucket)/functions/
gcloud functions deploy data-validator \
  --runtime python39 \
  --trigger-http \
  --entry-point validate_data \
  --source gs://$(terraform output -raw static_assets_bucket)/functions/data-validator.zip
